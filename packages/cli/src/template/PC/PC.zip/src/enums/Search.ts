// mitt 事件类型定义
export enum SearchEnum {
	DEPARTMENT = 'Department',
	COMPANY = 'Company',
	PERSON = 'Person',
	ZHIBIAO = 'Zhibiao',
	TEMPLATE = 'Template',
  PARAM = 'Param',
  ZHIBIAOFORRES = 'ZhibiaoForRes'
}
